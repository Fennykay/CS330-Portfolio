#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#include <iostream>         // cout, cerr

// GLM Math Header inclusions
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "camera.h"
#include "meshes.h"

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "OpenGL Learning"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    // Shader program
    GLuint gProgramId;
    GLuint gLampProgramId;

    GLuint gTextureIdPot;
    GLuint gTextureIdLeaf;
    GLuint gTextureIdBall;
    GLuint gTextureIdTable;
	GLuint gTextureIdCoaster;
    GLuint gTextureIdBook;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;

    Meshes meshes;
}

Camera gCamera(glm::vec3(0.56025f, 2.51745f, 16.5818f));
float gLastX = WINDOW_WIDTH / 2.0f;
float gLastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;

float gDeltaTime = 0.0f;
float gLastFrame = 0.0f;

float cameraSpeed = 2.5f;

bool orthoCam = false;
const glm::vec3 orthoCameraPosition(-0.156f, 4.142f, 16.958f);

// Light source color and position
glm::vec3 gLightColor(0.75f, 0.75f, 0.6f);
glm::vec3 gLightPosition(-20.0f, 9.0f, 12.5f);
glm::vec3 gLightObjectColor(1.0f,1.0f,1.0f);
glm::vec3 gLightScale(0.3f);

glm::vec3 gLightColor2(0.25f, 0.25f, 0.25f);
glm::vec3 gLightPosition2(7.17656f, 5.15959f, 0.295964f);
glm::vec3 gLightObjectColor2(1.0f, 1.0f, 1.0f);
glm::vec3 gLightScale2(0.3f);

//ambient light
glm::vec3 gAmbientLight(0.2f);
glm::vec3 gAmbientLightColor(1.0f, 1.0f, 1.0f);
glm::vec3 gAmbientLightPosition(0.0f, 0.0f, 0.0f);

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void flipImageVertically(unsigned char* image, int width, int height, int channels);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
	layout(location = 1) in vec3 normal;
	layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal;
    out vec3 vertexFragmentPos;
	out vec2 vertexTextureCoordinate;


	//Global variables for the transform matrices
	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
    vertexTextureCoordinate = textureCoordinate;
    vertexFragmentPos = vec3(model * vec4(position, 1.0f));
    vertexNormal = mat3(transpose(inverse(model))) * normal;
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate;
	in vec3 vertexNormal;
	in vec3 vertexFragmentPos;

	out vec4 fragmentColor;

	uniform sampler2D uTexture;
	uniform vec2 uvScale;
    uniform vec3 lightColor;
	uniform vec3 lightPos;
	uniform vec3 lightObjectColor;
	uniform vec3 lightScale;
    uniform vec3 lightColor2;
    uniform vec3 lightPos2;
    uniform vec3 lightObjectColor2;
    uniform vec3 lightScale2;
    uniform vec3 ambientLight;
    uniform vec3 ambientLightColor;


    void main()
    {
        // Texture sampling
        vec4 texColor = texture(uTexture, vertexTextureCoordinate * uvScale);

        // Ambient lighting
        float ambientStrength = 0.2f; // Set ambient or global lighting strength
        vec3 ambient = ambientStrength * ambientLightColor; // Combine ambient light colors

        // Diffuse lighting
        vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit

        // Calculate diffuse lighting for first light source
        vec3 lightDirection1 = normalize(lightPos - vertexFragmentPos);
        float diffuseFactor = max(dot(norm, lightDirection1), 0.0f);
        vec3 diffuse1 = diffuseFactor * lightColor * lightObjectColor;

        // Calculate diffuse lighting for second light source
        vec3 lightDirection2 = normalize(lightPos2 - vertexFragmentPos);
        diffuseFactor = max(dot(norm, lightDirection2), 0.0f);
        vec3 diffuse2 = diffuseFactor * lightColor2 * lightObjectColor2;

        // Combine diffuse lighting from both light sources
        vec3 diffuse = diffuse1 + diffuse2;

        // Specular lighting for first light
        float specularStrength = 0.5f; // Set specular lighting strength

        vec3 viewDir1 = normalize(vec3(-20.0f, 9.0f, 12.5f) - vertexFragmentPos);
        vec3 reflectDir1 = reflect(-lightDirection1, norm);
        float specularFactor1 = pow(max(dot(viewDir1, reflectDir1), 0.0f), 4.0f);
        vec3 specular1 = (specularStrength) * specularFactor1 * lightColor;

        vec3 viewDir2 = normalize(vec3(7.17656f, 5.15959f, 0.295964f) - vertexFragmentPos);
        vec3 reflectDir2 = reflect(-lightDirection2, norm);
        float specularFactor2 = pow(max(dot(viewDir2, reflectDir2), 0.0f), 1.0f);
        vec3 specular2 = specularStrength * specularFactor2 * lightColor2;

        vec3 specular = specular1 + specular2;

        // Combine ambient, diffuse, and specular lighting
        vec3 lighting = (ambient + diffuse + specular);

        // Final color with lighting applied
        fragmentColor = texColor * vec4(lighting, 1.0f); // Send combined color (texture * lighting) to GPU
    }
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

	void main()
	{
	    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
	}
);



void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

// Function for initializing textures
bool loadFunctions()
{
    // Load texture
    const char* texFilename = "./resources/textures/leaf.png"; //leaf texture
    if (!UCreateTexture(texFilename, gTextureIdLeaf))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }
    texFilename = "./resources/textures/white-marble.png"; // plant pot texture
    if (!UCreateTexture(texFilename, gTextureIdPot))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }
    texFilename = "./resources/textures/redball.png"; //ball texture
    if (!UCreateTexture(texFilename, gTextureIdBall))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }
    texFilename = "./resources/textures/wood.png"; // table texture
    if (!UCreateTexture(texFilename, gTextureIdTable))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }
    texFilename = "./resources/textures/coaster.png"; // coaster texture
    if (!UCreateTexture(texFilename, gTextureIdCoaster))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }
    texFilename = "./resources/textures/book.png"; // book texture
    if (!UCreateTexture(texFilename, gTextureIdBook))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }
    return true;
}

void bindTextures()
{
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdLeaf);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureIdPot);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureIdBall);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, gTextureIdTable);
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_2D, gTextureIdCoaster);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, gTextureIdBook);
}

void renderLoop()
{
    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;
        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
        cout << "Camera Position: " << gCamera.Position.x << ", " << gCamera.Position.y << ", " << gCamera.Position.z << endl;
    }
}

void destroyPrograms()
{
    // Release mesh data
    UDestroyMesh(gMesh);

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLampProgramId);
}

bool initProgram(int argc, char*argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return false;

    meshes.CreateMeshes();

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return false;
    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return false;
    if (!loadFunctions())
        return false;

    return true;
}


int main(int argc, char* argv[])
{
    if (!initProgram(argc, argv))
	{
		destroyPrograms();
		exit(EXIT_FAILURE);
	}

    glUseProgram(gProgramId);
    bindTextures();

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    renderLoop();
    destroyPrograms();

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    // pass key inputs to the camera class
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float cameraOffset = cameraSpeed * gDeltaTime;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
        cout << "Forward Input" << endl;
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
        cout << "Backwards Input" << endl;
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
        cout << "Left Input" << endl;
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
        cout << "Right Input" << endl;
    }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        gCamera.ProcessKeyboard(UP, gDeltaTime); // Move upwards when Q is pressed
        cout << "Up Input" << endl;
    }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        gCamera.ProcessKeyboard(DOWN, gDeltaTime); // Move downwards when E is pressed
        cout << "Down Input" << endl;
    }

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        orthoCam = !orthoCam;
        if (orthoCam)
        {
            gCamera.Position = orthoCameraPosition;
        }
    }
}

void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    // Pass the mouse input to the camera class
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    // Pass the scroll wheel input to the camera class
    gCamera.ProcessMouseScroll(yoffset);
}

void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    // Pass the mouse button input to the camera class
    cout << "Mouse button: " << button << " (" << action << ")" << endl;
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// Functioned called to render a frame
void URender()
{

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 1. Scales the object by 2
    glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    // 2. Rotates shape by 35 degrees on the Y axis
    glm::mat4 rotation = glm::rotate(35.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // Transforms the camera: move the camera back (z axis)
    glm::mat4 view = gCamera.GetViewMatrix();
    glm::mat4 projection;

    if (orthoCam)
    {
        float orthoSize = 5.0f;
        projection = glm::ortho(-orthoSize, orthoSize, -orthoSize, orthoSize, 0.1f, 100.0f);
    }
    else
    {
        projection = glm::perspective(45.0f, (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }



    // Set the shader to be used
    glUseProgram(gProgramId);

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0); // 0 is the texture slot to use

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    // creation of light object
    // Get the uniform locations
    GLuint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLuint lightPosLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLuint lightObjectColorLoc = glGetUniformLocation(gProgramId, "lightObjectColor");

    GLuint lightColorLoc2 = glGetUniformLocation(gProgramId, "lightColor2");
    GLuint lightPosLoc2 = glGetUniformLocation(gProgramId, "lightPos2");
    GLuint lightObjectColorLoc2 = glGetUniformLocation(gProgramId, "lightObjectColor2");

    // ambient light creation
    GLuint ambientLightLoc = glGetUniformLocation(gProgramId, "ambientLight");
    GLuint ambientLightColorLoc = glGetUniformLocation(gProgramId, "ambientLightColor");


    // Set the uniform values
    glUniform3fv(lightColorLoc, 1, glm::value_ptr(gLightColor));
    glUniform3fv(lightPosLoc, 1, glm::value_ptr(gLightPosition));
    glUniform3fv(lightObjectColorLoc, 1, glm::value_ptr(gLightObjectColor));

    glUniform3fv(lightColorLoc2, 1, glm::value_ptr(gLightColor2));
    glUniform3fv(lightPosLoc2, 1, glm::value_ptr(gLightPosition2));
    glUniform3fv(lightObjectColorLoc2, 1, glm::value_ptr(gLightObjectColor2));

    glUniform3fv(ambientLightLoc, 1, glm::value_ptr(gAmbientLight));
    glUniform3fv(ambientLightColorLoc, 1, glm::value_ptr(gAmbientLightColor));


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    ///-------Transform and draw the bottom plane --------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gPlaneMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(9.0f, 1.0f, 15.0f));
    // 2. Rotate the object
    rotation = glm::rotate(glm::radians(-45.0f), glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(1.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3); // 3 is the texture slot to use

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    ///-------Transform and draw the box mesh --------
    ///item=book
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gBoxMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(4.5f, 0.4f, 3.0f));
    // 2. Rotate the object
    rotation = glm::rotate(27.0f, glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(3.01351f, 0.24f, 1.303471f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5); // 5 is the texture slot to use

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    ///-------Transform and draw the cylinder mesh --------
    /// item=COASTER1
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(1.0f, 0.1f, 1.0f));
    // 2. Rotate the object
    rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-0.5f, 0.0f, 8.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 4); // 4 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    ///-------Transform and draw the cylinder mesh --------
    /// item=COASTER2
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(1.0f, 0.1f, 1.0f));
    // 2. Rotate the object
    rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-3.5f, 0.0f, 7.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 4); // 4 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    ///-------Transform and draw the cylinder mesh --------
    /// item=PLANT_POT
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(1.0f, 1.8f, 1.0f));
    // 2. Rotate the object
    rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.2f, 0.2f, 5.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 1); // 1 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    ///-------Transform and draw the cylinder mesh --------
    /// item=PLANT_LEAF_CENTER
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 1.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.2f, 2.0f, 5.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0); // 0 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    ///-------Transform and draw the cylinder mesh --------
    /// item=PLANT_LEAF_DIAGONAL (x, z)
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 1.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(45.0f, glm::vec3(1.0, 0.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.2f, 2.0f, 5.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

   

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    ///-------Transform and draw the cylinder mesh --------
    /// item=PLANT_LEAF_DIAGONAL (-x, -z
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 1.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(-45.0f, glm::vec3(1.0, 0.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.2f, 2.0f, 5.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));



    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    ///-------Transform and draw the cylinder mesh --------
    /// item=PLANT_LEAF_DIAGONAL (x)
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 1.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(45.0f, glm::vec3(1.0, 0.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.2f, 2.0f, 5.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

   

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    /// PLANT POT translate = translation = glm::translate(glm::vec3(-1.2f, 1.2f, 5.5f));
    ///	^^^ for position purposes
    ///-------Transform and draw the tapered cylinder mesh --------
    ///item=PLANT_POT_LEG1
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gTaperedCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 0.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.7f, 0.2f, 6.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 1); // 1 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    /// PLANT POT translate = translation = glm::translate(glm::vec3(-1.2f, 1.2f, 5.5f));
    ///	^^^ for position purposes
    ///-------Transform and draw the tapered cylinder mesh --------
    ///item=PLANT_POT_LEG3
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gTaperedCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 0.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-1.3f, 0.2f, 4.8f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 1); // 1 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    /// PLANT POT translate = translation = glm::translate(glm::vec3(-1.2f, 1.2f, 5.5f));
    ///	^^^ for position purposes
    ///-------Transform and draw the tapered cylinder mesh --------
    ///item=PLANT_POT_LEG2
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gTaperedCylinderMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 0.2f, 0.2f));
    // 2. Rotate the object
    rotation = glm::rotate(glm::radians(180.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-0.5f, 0.2f, 5.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 1); // 1 is the texture slot to use

    // Draws the triangles
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    ///-------Transform and draw the cat ball mesh --------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(meshes.gSphereMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.3f, 0.3f, 0.3f));
    // 2. Rotate the object
    rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Position the object
    translation = glm::translate(glm::vec3(-0.554781f, 0.39f, 8.48716f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 2); // 2 is the texture slot to use

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}



void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

